#include<stdio.h>
#include<string.h>
//#include<conio.h>

int main()
{
    char a[100],b[100];
    int n,count=0,i,j,check=0;
    
    printf("Enter the string:");
    gets(a);
    
    n=strlen(a);
    
    for(i=0;i<n;i++)
    {
                    
                    if(a[i]==' '&&a[i+1]==' ')
                    {
                               check++;
                               continue;
                    }
                    b[i-check]=a[i];
    }
                               
    
    printf("Answer:");
    puts(b);
  //  getch();
    return 0;
}
                    

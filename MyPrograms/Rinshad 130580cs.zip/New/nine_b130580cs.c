#include<stdio.h>
//#include<conio.h>

int main()
{
    int i,rem,qs,pro;
    
    for(i=32;i<=99;i++)
    {
                       pro=i*i;
                       rem=pro%100;
                       qs=pro/100;
                       
                       if(i==rem+qs)
                       printf("%d\t",i);
    }
    
  //  getch();
    return 0;
}

                       

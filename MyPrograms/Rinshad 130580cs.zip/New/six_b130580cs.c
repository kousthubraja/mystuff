#include<stdio.h>
#include<string.h>
//#include<conio.h>

int main()
{
    char a[100],b[25];
    int i,j,n,m,check;
    
    printf("Enter the string:");
    gets(a);
    
    printf("Enter the substring:");
    gets(b);
    
    n=strlen(a);
    m=strlen(b);
    
    for(i=0;i<n-m;i++)
    {
                     if(a[i]=b[0])
                     {
                                  check=0;
                                  for(j=0;j<m;j++)
                                  {
                                                  if(a[i+j]==b[j])
                                                  check++;
                                  }
                     }
    
              if(check==m)
              break;       
                     
    }
    
    if (check==m)
    printf("\"%s\" is a substring",b);
    else
    printf("Not a substring");
    
  //  getch();
    return 0;
}          
                                                   
                                  
                                                 

#include<stdio.h>
//#include<conio.h>

int twr(char a,char b, char c,int n)
{
  	if(n==1)
  	{
  	 printf("\n\tmove the disc 1 from %c to %c",a,b); 
  	 return 0;
  	}
  	
  	twr(a,c,b,n-1);
  	printf("\n\tmove the disc %d from %c to %c",n,a,b);
  	twr(c,b,a,n-1);
}
  	 
  	
  	
  	
int main()
{
	int n;
	char a='A',b='B',c='C';
	
	
	printf("Enter the number of disc want to use");
	scanf("%d",&n);
	
	printf("To solve the TOWER OF HANOI move the disc in the following  manner:");
	twr(a,b,c,n);
//getch();	
	return 0;
}
	
	
	

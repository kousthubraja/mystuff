#include<stdio.h>
//#include<conio.h>
#include<math.h>

int main()
{
    int a[100],b[100]={},i,j,n,temp,k;
    float mean,sum=0,sd;
    
    printf("no of elements:");
    scanf("%d",&n);
    
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    
    for(i=0;i<n;i++)
    sum=sum+a[i];
    mean=sum/n;
    printf("mean=%f",mean);
    sum=0;
    
    
       for(i=0;i<n;i++)
       {
                       sum=sum+(mean-a[i])*(mean-a[i]);
                       for(j=0;j<n;j++)
                       {
                                       if(a[i]>a[j])
                                       {
                                                    temp=a[j];
                                                    a[j]=a[i];
                                                    a[i]=temp;
                                       }
                       }
       }
       sd=sqrt(sum/n);
       printf("\nstandard deviation=%f",sd);
     if(n%2==1)
     printf("\nMeadian=%d",a[n/2]);
     else
     printf("\nMeadian=%f",((float)a[n/2]+a[n/2-1])/2);
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<n;j++)
                     {
                      if(a[i]==a[j])
                      b[i]=b[i]+1;
                     }
     }
     
          
      temp=0;                               
      for(i=0;i<n;i++)
      {
                      if(b[temp]<b[i])
                      temp=i;
      }
      
      if(b[temp]==1)
      printf("\nno mode value");
      else
      {
          for(i=0;i<n;i++)
          {
                          if(b[temp]==b[i]&&temp!=i&&a[temp]!=a[i])
                          {
                          printf("\n no mode value");
                          k=1;
                          break;
                          }
          }
      }
      if(k!=1&&b[temp]!=1)
      printf("\nMode=%d",a[temp]);
      
      
   // getch();
    return 0;
}

#include<stdio.h>
#include<string.h>
//#include<conio.h>
#include<ctype.h>

int isvowel(char x)
{
    x=toupper(x);
    if(x=='A'||x=='E'||x=='I'||x=='O'||x=='U')
    return 1;
    else
    return 0;
}


int main()
{
    char a[1000],b[1000];
    int n,i,j;
    
    printf("Enter the string:");
    gets(a);
    
    n=strlen(a);
    j=0;
    
    for(i=0;i<n;i++)
    {
                    if(!isvowel(a[i]))
                    {
                                     b[j]=a[i];
                                     j++;
                    }
    }
    b[j]='\0';
    
    printf("After deleting vowel:");
    puts(b);
    
  //  getch();
    return 0;
}

                                    

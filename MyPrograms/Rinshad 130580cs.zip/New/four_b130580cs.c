#include<stdio.h>
#include<string.h>
//#include<conio.h>

int main()
{
    char a[100][100],temp[100];
    int n,i,j;
    
    
    printf("Enter how many works to enter:");
    scanf("%d",&n);
    
    printf("Enter the words:\n");
    for(i=0;i<n;i++)
    //gets(a[i]);
    scanf("%s",a[i]);
    
    for(i=0;i<n;i++)
    {
                   for(j=0;j<n;j++)
                   {
                                   if(strcmp(a[i],a[j])<0)
                                   {
                                                          strcpy(temp,a[j]);
                                                          strcpy(a[j],a[i]);
                                                          strcpy(a[i],temp);
                                   }
                   }
    }
    
    
    printf("\n\nAfter sorting:\n");
    for(i=0;i<n;i++)
    {
                    puts(a[i]);
                    //printf("\n");
    }
    
    //getch();
    return 0;
}
   

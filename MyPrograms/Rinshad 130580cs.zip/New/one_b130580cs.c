#include<stdio.h>
//#include<conio.h>
#define k 100


int a[k][k],b[k][k],i,j,dn;


void entermatrix( int zoo[100][100], int n,int m)
{
     
    
    for(i=0;i<n;i++)
    {
                    for(j=0;j<m;j++)
                    {
                                    scanf("%d",&zoo[i][j]);
                    }
    }
    
    
}

void printmatrix( int zoo[100][100],int n,int m)
{
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<m;j++)
                     {

                                     printf("%d  ",zoo[i][j]);
                     }
     printf("\n");
     }
}

void sum(void)
{
    int n,m,sum[k][k];
    
    printf("\nEnter the values of n& m:");
    scanf("%d%d",&n,&m);
    printf("\nEnter the first matrix:\n");
    entermatrix(a,n,m);
    printf("\nEnter the second matrix:\n");
    entermatrix(b,n,m);
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<m;j++)
                     {
                                     sum[i][j]=a[i][j]+b[i][j];
                     
                     }
     }
     printf("\nSum of the matrix=\n");
     printmatrix(sum,n,m);
}

void diff(void)
{
     int n,m,dif[k][k];                 
     
     printf("\nEnter the values of n& m:");
     scanf("%d%d",&n,&m);
    
     entermatrix(a,n,m);
     entermatrix(b,n,m);
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<m;j++)
                     {
                                     dif[i][j]=a[i][j]-b[i][j];
                     
                     }
     }
    printf("\n Defference of the matris:\n");
    printmatrix(dif,n,m); 
}

void mul(void)
{
     int mult[k][k]={},n,m,n1,m1,l,h;
     label1:
     printf("\nEnter n & m values for first matrix:");
     scanf("%d%d",&n,&m);
     printf("Enter n and m values for second matrix");
     scanf("%d%d",&n1,&m1);
     if(m!=n1)
     {
              printf("Entered matrix cannot be multiplied\n\ttry again");
              goto label1;
     }
     printf("\nEnter the first matrix\n");
     entermatrix(a,n,m);
     printf("Enter the second matrix\n");
     entermatrix(b,n1,m1);
     printmatrix(mult,2,2);
     for(i=0;i<n;i++)
     {
                     for(j=0;j<m1;j++)
                     {
                         
                          
                                      for(l=0;l<m;l++)
                                      {
                                        mult[i][j]=mult[i][j]+a[i][l]*b[l][j];
                                       }
                           } 
                     
     }
     
     pri
     ntf("\nProduct of two matrix:\n");
     printmatrix(mult,n,m1);
}



int fdet(int n, int b[k][k])
{
	int d=0,c,sign=1;

	if(n==2)
		return b[0][0]*b[1][1]-b[0][1]*b[1][0];
	else
	{
		int sm[k][k];
		int si,sj;

		for(c=0;c<n;c++)
		{
			si=0;
			for(i=1;i<n;i++,si++)
			{
				sj=0;
				for(j=0;j<n;j++)
				{
					if(j!=col)
					{
						sm[si][sj]=b[i][j];
						sj++;
					}
				}
			}

			sign=(col%2==0)?1:-1;
			d+=sign*b[0][col]*fdet(n-1,sm);
		}
		return d;
	}
}





void det()
{
                 printf"Enter the number value of n:");
                 scanf("%d",&n); 
    
                 entermatrix(a,n,n);
                 printf("\n Determinent valu=%d",fdet(n,a));
 }









void trans(void)
{
     int n,m;
     int tran[k][k]={};
     printf("\nEnter the values of n and m:");
     scanf("%d%d",&n,&m);
     
     printf("Enter the matrix:\n");
     entermatrix(a,n,m);
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<m;j++)
                     {
                                     b[j][i]=a[i][j];
                     }
     }
     
     printf("Transpose of matrix:\n");
     printmatrix(b,m,n);
}


void suml(void)
{
     int n,m,sum=0;
     printf("Enter the values of n amd m:");
     scanf("%d%d",&n,&m);
     
     printf("Entr the martrix:\n");
     entermatrix(a,n,m);
     
     for(i=0;i<n;i++)
     {
                     for(j=0;j<n;j++)
                     {
                                     sum=sum+a[i][j];
                     }
     }
     
     printf("Sumof elements=%d",sum);
}
                     
     
     
     
     
     
                                              
int main()
{
    
    int check;
    
    printf("\n select the operation want to do\n1\tsum\n2\tdifference \n3\tmultiplication\n4\tdeterminent\n5\ttranspose\n6\tsum of elements\n:");
    
    scanf("%d",&check);
    
    switch(check)
    {
                 case 1:
                      sum();
                      break;
                 case 2:
                      diff();
                      break;
                 case 3:
                      mul();
                      break;
                 case 4:
                      det();
                      break;  
                 case 5:
                      trans();
                      break;
                 case 6:
                      suml(); 
                      break;
                 default:
                         printf("****INVALID CHOICE****");
                         break;
    }             
   // getch();
    return 0;
}

    
                         
                 
                      

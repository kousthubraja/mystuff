#include<stdio.h>
//#include<conio.h>

int main()
{
    int a[100],i,j,check=1,n,temp;
    
    printf("Enter the number of elements in array:");
    scanf("%d",&n);
    
    printf("Enbter the Array:\n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    
    //check=1;
    for(i=0;(i<n)&&check;i++)
    {
                           check=0;
                           for(j=1;j<n;j++)
                           {
                                             if(a[j]>a[j-1])
                                             {
                                                             temp=a[j-1];
                                                             a[j-1]=a[j];
                                                             a[j]=temp;
                                                             check=1;
                                             }
                           }
    }
    
    printf("Sorted array:");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    
   // getch();
    return 0;
}

#include<stdio.h>
#include<math.h>

int gcd(int,int);
int lcm(int,int);


int main()
{
    int a,b;
    printf("Enter two numbers : ");
    scanf("%d %d",&a,&b);
    printf("%d",gcd(a,b));
    printf("\n");
    return 0;
}

int gcd(int a,int b)
{
    int i;
    if(a<b)
    {
        i=a;
        while(i)
        {
            if(b%i==0 && a%i==0)
                return i;
            i--;
        }
    }
    else
    {
        i=b;
        while(i)
        {
            if(b%i==0 && a%i==0)
                return i;
            i--;
        }
    }
}

int lcm(int a,int b)
{

}
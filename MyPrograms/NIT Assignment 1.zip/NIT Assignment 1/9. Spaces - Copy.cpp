#include<stdio.h>

int main()
{
	char c;
    int i=0,state=0,count=0;
    c=getchar();
    while(c!=13)
    {
      if(c==' ' && state==1)
      {
        state=0;
        count++;
      }
      else
        state=1;
      i++;
    }
    printf("Space is %d",count);
    scanf("%d",&s);
}
    

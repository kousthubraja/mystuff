Title: HTTP File Upload client (Upload file directly to web server not ftp)
Description: Sometimes programmers needs to upload file directly
to HTTP Webpage instead of uploading to FTP server.
This client mimics the HTML upload page and will
upload multiple files to web server using HTTP protocol. This example shows how to upload file from client desktop to apache webserver. PHP script also included.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55649&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

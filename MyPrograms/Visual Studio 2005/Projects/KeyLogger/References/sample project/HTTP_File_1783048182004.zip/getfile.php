
<?php

//Put this php upload script in your apache php webserver.
//Set the url to this script in your vb upload client

$location = "";      //Left blank if upload in same folder
$max_size = 1000000; //File upload size

print("$value1 $value2\r\n"); //Check for extra posted variable - u can add ur own here

//This loop here will save ur file to the server
for ($num = 1; $num < $slots+1; $num++){

    $event = "Success";
	
    // Check if upload for field is required
    if (! $_FILES['upload'.$num]['name'] == ""){
      if ($_FILES['upload'.$num]['size'] < $max_size) {		
        move_uploaded_file($_FILES['upload'.$num]['tmp_name'],$location.$_FILES['upload'.$num]['name']) or $event = "Failure";
	   } else {
	    $event = "File too large!";
	   }
	   print("Uploading File $num $event\r\n");
	}
  }

?> 

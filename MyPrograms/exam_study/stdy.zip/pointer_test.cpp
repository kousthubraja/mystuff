#include<iostream.h>
#include<conio.h>

int main()
{
    int v;
    int *p;
    cin>>v;
    p=&v;
    
    getch();
    return 0;
}

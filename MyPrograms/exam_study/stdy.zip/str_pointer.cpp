#include<iostream.h>

int main()
{
    char a[]={"hello"};
    char *b;
    b=a;
    cout<<b;
    b++;
    cout<<b;
    cin>>a;
}

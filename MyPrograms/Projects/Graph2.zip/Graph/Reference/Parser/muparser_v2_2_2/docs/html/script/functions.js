//--------------------------------------------------
//
// Bedingte darstellung des SourceForge logos
//
function SFLogo()
{
  document.write("<img src=\"http:\/\/sourceforge.net\/sflogo.php?group_id=137191&amp;type=5\" width=\"210\" height=\"62\" border=\"0\" alt=\"SourceForge.net Logo\" \/>");
}


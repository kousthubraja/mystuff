/** Automatically generated file. DO NOT MODIFY */
package test.kr.maptest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}